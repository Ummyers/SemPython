Para compilar el programa:

mpicc tarea2.c -lm -o s.out

Para ejecutar el programa:

mpirun -np 1 s.out

Para cambiar los puntos generados deberás cambiar la directiva N que se encuentra al principio del programa.